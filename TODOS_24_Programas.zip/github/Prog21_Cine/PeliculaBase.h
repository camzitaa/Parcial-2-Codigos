#pragma once
#include "IPelicula.h"
#include <iostream>

// CLASE ABSTRACTA
class PeliculaBase : public IPelicula {
protected:
    std::string titulo;
    std::string genero;
    double duracion;
    double precio;
public:
    PeliculaBase(std::string titulo, std::string genero, double duracion, double precio)
        : titulo(titulo), genero(genero), duracion(duracion), precio(precio) {}

    std::string getTitulo() override { return titulo; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Pelicula ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
