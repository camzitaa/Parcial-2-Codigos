#pragma once
#include "PeliculaBase.h"

// IMPLEMENTACION CONCRETA
class Pelicula : public PeliculaBase {
public:
    Pelicula(std::string titulo, std::string genero, double duracion, double precio)
        : PeliculaBase(titulo, genero, duracion, precio) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  titulo: " << titulo << std::endl;
        std::cout << "  genero: " << genero << std::endl;
        std::cout << "  duracion: " << duracion << std::endl;
        std::cout << "  precio: " << precio << std::endl;
    }
};
