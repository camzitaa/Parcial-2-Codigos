#pragma once
#include <string>

// INTERFAZ
class IMateria {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getNombre() = 0;
    virtual double getCreditos() = 0;
    virtual ~IMateria() {}
};
