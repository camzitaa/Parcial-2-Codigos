#pragma once
#include "IMateria.h"
#include <iostream>

// CLASE ABSTRACTA
class MateriaBase : public IMateria {
protected:
    std::string nombre;
    std::string profesor;
    double creditos;
    int cupo;
public:
    MateriaBase(std::string nombre, std::string profesor, double creditos, int cupo)
        : nombre(nombre), profesor(profesor), creditos(creditos), cupo(cupo) {}

    std::string getNombre() override { return nombre; }
    double getCreditos() override { return (double)creditos; }

    void mostrarEncabezado() {
        std::cout << "---- Materia ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
