#pragma once
#include "MateriaBase.h"

// IMPLEMENTACION CONCRETA
class Materia : public MateriaBase {
public:
    Materia(std::string nombre, std::string profesor, double creditos, int cupo)
        : MateriaBase(nombre, profesor, creditos, cupo) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  nombre: " << nombre << std::endl;
        std::cout << "  profesor: " << profesor << std::endl;
        std::cout << "  creditos: " << creditos << std::endl;
        std::cout << "  cupo: " << cupo << std::endl;
    }
};
