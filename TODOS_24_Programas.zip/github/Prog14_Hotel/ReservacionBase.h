#pragma once
#include "IReservacion.h"
#include <iostream>

// CLASE ABSTRACTA
class ReservacionBase : public IReservacion {
protected:
    std::string huesped;
    int habitacion;
    double noches;
    double total;
public:
    ReservacionBase(std::string huesped, int habitacion, double noches, double total)
        : huesped(huesped), habitacion(habitacion), noches(noches), total(total) {}

    std::string getHuesped() override { return huesped; }
    double getTotal() override { return (double)total; }

    void mostrarEncabezado() {
        std::cout << "---- Reservacion ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
