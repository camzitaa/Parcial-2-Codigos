#pragma once
#include <string>

// INTERFAZ
class IReservacion {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getHuesped() = 0;
    virtual double getTotal() = 0;
    virtual ~IReservacion() {}
};
