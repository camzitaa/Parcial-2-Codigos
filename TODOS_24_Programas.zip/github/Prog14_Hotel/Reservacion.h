#pragma once
#include "ReservacionBase.h"

// IMPLEMENTACION CONCRETA
class Reservacion : public ReservacionBase {
public:
    Reservacion(std::string huesped, int habitacion, double noches, double total)
        : ReservacionBase(huesped, habitacion, noches, total) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  huesped: " << huesped << std::endl;
        std::cout << "  habitacion: " << habitacion << std::endl;
        std::cout << "  noches: " << noches << std::endl;
        std::cout << "  total: " << total << std::endl;
    }
};
