#pragma once
#include "IMascota.h"
#include <iostream>

// CLASE ABSTRACTA
class MascotaBase : public IMascota {
protected:
    std::string nombre;
    std::string especie;
    double edad;
    std::string duenio;
public:
    MascotaBase(std::string nombre, std::string especie, double edad, std::string duenio)
        : nombre(nombre), especie(especie), edad(edad), duenio(duenio) {}

    std::string getNombre() override { return nombre; }
    double getEdad() override { return (double)edad; }

    void mostrarEncabezado() {
        std::cout << "---- Mascota ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
