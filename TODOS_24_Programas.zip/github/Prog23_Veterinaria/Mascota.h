#pragma once
#include "MascotaBase.h"

// IMPLEMENTACION CONCRETA
class Mascota : public MascotaBase {
public:
    Mascota(std::string nombre, std::string especie, double edad, std::string duenio)
        : MascotaBase(nombre, especie, edad, duenio) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  nombre: " << nombre << std::endl;
        std::cout << "  especie: " << especie << std::endl;
        std::cout << "  edad: " << edad << std::endl;
        std::cout << "  duenio: " << duenio << std::endl;
    }
};
