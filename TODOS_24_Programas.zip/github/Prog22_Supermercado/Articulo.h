#pragma once
#include "ArticuloBase.h"

// IMPLEMENTACION CONCRETA
class Articulo : public ArticuloBase {
public:
    Articulo(std::string nombre, std::string categoria, double precio, int stock)
        : ArticuloBase(nombre, categoria, precio, stock) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  nombre: " << nombre << std::endl;
        std::cout << "  categoria: " << categoria << std::endl;
        std::cout << "  precio: " << precio << std::endl;
        std::cout << "  stock: " << stock << std::endl;
    }
};
