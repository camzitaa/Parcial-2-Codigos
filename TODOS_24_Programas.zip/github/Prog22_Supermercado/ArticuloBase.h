#pragma once
#include "IArticulo.h"
#include <iostream>

// CLASE ABSTRACTA
class ArticuloBase : public IArticulo {
protected:
    std::string nombre;
    std::string categoria;
    double precio;
    int stock;
public:
    ArticuloBase(std::string nombre, std::string categoria, double precio, int stock)
        : nombre(nombre), categoria(categoria), precio(precio), stock(stock) {}

    std::string getNombre() override { return nombre; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Articulo ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
