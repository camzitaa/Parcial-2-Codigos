#pragma once
#include "IVuelo.h"
#include <iostream>

// CLASE ABSTRACTA
class VueloBase : public IVuelo {
protected:
    std::string destino;
    std::string hora;
    int asientos;
    double precio;
public:
    VueloBase(std::string destino, std::string hora, int asientos, double precio)
        : destino(destino), hora(hora), asientos(asientos), precio(precio) {}

    std::string getDestino() override { return destino; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Vuelo ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
