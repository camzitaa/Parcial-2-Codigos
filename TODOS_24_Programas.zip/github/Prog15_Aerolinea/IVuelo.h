#pragma once
#include <string>

// INTERFAZ
class IVuelo {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getDestino() = 0;
    virtual double getPrecio() = 0;
    virtual ~IVuelo() {}
};
