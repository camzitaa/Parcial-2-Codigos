#pragma once
#include "VueloBase.h"

// IMPLEMENTACION CONCRETA
class Vuelo : public VueloBase {
public:
    Vuelo(std::string destino, std::string hora, int asientos, double precio)
        : VueloBase(destino, hora, asientos, precio) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  destino: " << destino << std::endl;
        std::cout << "  hora: " << hora << std::endl;
        std::cout << "  asientos: " << asientos << std::endl;
        std::cout << "  precio: " << precio << std::endl;
    }
};
