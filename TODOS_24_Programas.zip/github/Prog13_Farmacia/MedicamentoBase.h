#pragma once
#include "IMedicamento.h"
#include <iostream>

// CLASE ABSTRACTA
class MedicamentoBase : public IMedicamento {
protected:
    std::string nombre;
    std::string dosis;
    double precio;
    int cantidad;
public:
    MedicamentoBase(std::string nombre, std::string dosis, double precio, int cantidad)
        : nombre(nombre), dosis(dosis), precio(precio), cantidad(cantidad) {}

    std::string getNombre() override { return nombre; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Medicamento ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
