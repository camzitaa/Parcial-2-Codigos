#pragma once
#include "MedicamentoBase.h"

// IMPLEMENTACION CONCRETA
class Medicamento : public MedicamentoBase {
public:
    Medicamento(std::string nombre, std::string dosis, double precio, int cantidad)
        : MedicamentoBase(nombre, dosis, precio, cantidad) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  nombre: " << nombre << std::endl;
        std::cout << "  dosis: " << dosis << std::endl;
        std::cout << "  precio: " << precio << std::endl;
        std::cout << "  cantidad: " << cantidad << std::endl;
    }
};
