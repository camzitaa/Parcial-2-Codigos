#pragma once
#include <string>

// INTERFAZ
class IPlatillo {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getNombre() = 0;
    virtual double getPrecio() = 0;
    virtual ~IPlatillo() {}
};
