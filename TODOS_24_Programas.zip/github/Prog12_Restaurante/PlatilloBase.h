#pragma once
#include "IPlatillo.h"
#include <iostream>

// CLASE ABSTRACTA
class PlatilloBase : public IPlatillo {
protected:
    std::string nombre;
    std::string categoria;
    double precio;
    int calorias;
public:
    PlatilloBase(std::string nombre, std::string categoria, double precio, int calorias)
        : nombre(nombre), categoria(categoria), precio(precio), calorias(calorias) {}

    std::string getNombre() override { return nombre; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Platillo ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
