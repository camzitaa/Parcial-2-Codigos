#pragma once
#include "PlatilloBase.h"

// IMPLEMENTACION CONCRETA
class Platillo : public PlatilloBase {
public:
    Platillo(std::string nombre, std::string categoria, double precio, int calorias)
        : PlatilloBase(nombre, categoria, precio, calorias) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  nombre: " << nombre << std::endl;
        std::cout << "  categoria: " << categoria << std::endl;
        std::cout << "  precio: " << precio << std::endl;
        std::cout << "  calorias: " << calorias << std::endl;
    }
};
