#pragma once
#include <string>

// INTERFAZ
class IPedido {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getCliente() = 0;
    virtual double getPrecio() = 0;
    virtual ~IPedido() {}
};
