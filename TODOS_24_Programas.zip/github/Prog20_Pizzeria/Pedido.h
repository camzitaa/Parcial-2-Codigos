#pragma once
#include "PedidoBase.h"

// IMPLEMENTACION CONCRETA
class Pedido : public PedidoBase {
public:
    Pedido(std::string cliente, std::string tamano, double precio, int cantidad)
        : PedidoBase(cliente, tamano, precio, cantidad) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  cliente: " << cliente << std::endl;
        std::cout << "  tamano: " << tamano << std::endl;
        std::cout << "  precio: " << precio << std::endl;
        std::cout << "  cantidad: " << cantidad << std::endl;
    }
};
