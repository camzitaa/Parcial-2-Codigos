#pragma once
#include "IPedido.h"
#include <iostream>

// CLASE ABSTRACTA
class PedidoBase : public IPedido {
protected:
    std::string cliente;
    std::string tamano;
    double precio;
    int cantidad;
public:
    PedidoBase(std::string cliente, std::string tamano, double precio, int cantidad)
        : cliente(cliente), tamano(tamano), precio(precio), cantidad(cantidad) {}

    std::string getCliente() override { return cliente; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Pedido ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
