#pragma once
#include "MembresiaBase.h"

// IMPLEMENTACION CONCRETA
class Membresia : public MembresiaBase {
public:
    Membresia(std::string cliente, std::string plan, double mensualidad, int meses)
        : MembresiaBase(cliente, plan, mensualidad, meses) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  cliente: " << cliente << std::endl;
        std::cout << "  plan: " << plan << std::endl;
        std::cout << "  mensualidad: " << mensualidad << std::endl;
        std::cout << "  meses: " << meses << std::endl;
    }
};
