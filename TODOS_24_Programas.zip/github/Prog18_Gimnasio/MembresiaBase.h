#pragma once
#include "IMembresia.h"
#include <iostream>

// CLASE ABSTRACTA
class MembresiaBase : public IMembresia {
protected:
    std::string cliente;
    std::string plan;
    double mensualidad;
    int meses;
public:
    MembresiaBase(std::string cliente, std::string plan, double mensualidad, int meses)
        : cliente(cliente), plan(plan), mensualidad(mensualidad), meses(meses) {}

    std::string getCliente() override { return cliente; }
    double getMensualidad() override { return (double)mensualidad; }

    void mostrarEncabezado() {
        std::cout << "---- Membresia ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
