#pragma once
#include <string>

// INTERFAZ
class IMembresia {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getCliente() = 0;
    virtual double getMensualidad() = 0;
    virtual ~IMembresia() {}
};
