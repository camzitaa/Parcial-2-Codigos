#pragma once
#include "CancionBase.h"

// IMPLEMENTACION CONCRETA
class Cancion : public CancionBase {
public:
    Cancion(std::string titulo, std::string artista, double duracion, double precio)
        : CancionBase(titulo, artista, duracion, precio) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  titulo: " << titulo << std::endl;
        std::cout << "  artista: " << artista << std::endl;
        std::cout << "  duracion: " << duracion << std::endl;
        std::cout << "  precio: " << precio << std::endl;
    }
};
