#pragma once
#include "ICancion.h"
#include <iostream>

// CLASE ABSTRACTA
class CancionBase : public ICancion {
protected:
    std::string titulo;
    std::string artista;
    double duracion;
    double precio;
public:
    CancionBase(std::string titulo, std::string artista, double duracion, double precio)
        : titulo(titulo), artista(artista), duracion(duracion), precio(precio) {}

    std::string getTitulo() override { return titulo; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Cancion ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
