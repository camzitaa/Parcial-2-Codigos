#pragma once
#include "PaqueteBase.h"

// IMPLEMENTACION CONCRETA
class Paquete : public PaqueteBase {
public:
    Paquete(std::string destino, int dias, double precio, int cupo)
        : PaqueteBase(destino, dias, precio, cupo) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  destino: " << destino << std::endl;
        std::cout << "  dias: " << dias << std::endl;
        std::cout << "  precio: " << precio << std::endl;
        std::cout << "  cupo: " << cupo << std::endl;
    }
};
