#pragma once
#include "IPaquete.h"
#include <iostream>

// CLASE ABSTRACTA
class PaqueteBase : public IPaquete {
protected:
    std::string destino;
    int dias;
    double precio;
    int cupo;
public:
    PaqueteBase(std::string destino, int dias, double precio, int cupo)
        : destino(destino), dias(dias), precio(precio), cupo(cupo) {}

    std::string getDestino() override { return destino; }
    double getPrecio() override { return (double)precio; }

    void mostrarEncabezado() {
        std::cout << "---- Paquete ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
