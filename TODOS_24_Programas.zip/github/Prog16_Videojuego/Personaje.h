#pragma once
#include "PersonajeBase.h"

// IMPLEMENTACION CONCRETA
class Personaje : public PersonajeBase {
public:
    Personaje(std::string nombre, std::string clase, double nivel, int vida)
        : PersonajeBase(nombre, clase, nivel, vida) {}

    void mostrarDatos() override {
        mostrarEncabezado();
        std::cout << "  nombre: " << nombre << std::endl;
        std::cout << "  clase: " << clase << std::endl;
        std::cout << "  nivel: " << nivel << std::endl;
        std::cout << "  vida: " << vida << std::endl;
    }
};
