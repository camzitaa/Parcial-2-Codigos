#pragma once
#include <string>

// INTERFAZ
class IPersonaje {
public:
    virtual void mostrarDatos() = 0;
    virtual std::string getNombre() = 0;
    virtual double getNivel() = 0;
    virtual ~IPersonaje() {}
};
