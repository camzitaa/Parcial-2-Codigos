#pragma once
#include "Personaje.h"

// PILA estatica con arreglo
class Pila {
private:
    static const int MAX = 50;
    Personaje* datos[MAX];
    int tope;
public:
    Pila() : tope(-1) {}

    void push(Personaje* e) {
        if(tope < MAX-1) datos[++tope] = e;
        else std::cout << "Pila llena." << std::endl;
    }

    Personaje* pop() {
        if(!estaVacia()) return datos[tope--];
        std::cout << "Pila vacia." << std::endl;
        return nullptr;
    }

    bool estaVacia() { return tope == -1; }
    int obtenerCantidad() { return tope+1; }

    void copiarCampo(double* arr, int& n) {
        n = tope+1;
        for(int i=0;i<=tope;i++) arr[i] = datos[i]->getNivel();
    }

    void mostrar() {
        if(estaVacia()){ std::cout<<"Pila vacia."<<std::endl; return; }
        std::cout<<"=== VIDEOJUEGO - PERSONAJES ==="<<std::endl;
        for(int i=tope;i>=0;i--) datos[i]->mostrarDatos();
    }
};
