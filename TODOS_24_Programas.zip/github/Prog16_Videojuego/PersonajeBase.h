#pragma once
#include "IPersonaje.h"
#include <iostream>

// CLASE ABSTRACTA
class PersonajeBase : public IPersonaje {
protected:
    std::string nombre;
    std::string clase;
    double nivel;
    int vida;
public:
    PersonajeBase(std::string nombre, std::string clase, double nivel, int vida)
        : nombre(nombre), clase(clase), nivel(nivel), vida(vida) {}

    std::string getNombre() override { return nombre; }
    double getNivel() override { return (double)nivel; }

    void mostrarEncabezado() {
        std::cout << "---- Personaje ----" << std::endl;
    }

    virtual void mostrarDatos() = 0;
};
